package com.example.cs360_project;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.Toast;

public class MainActivity2 extends AppCompatActivity {
    private static final int MY_PERMISSIONS_REQUEST_RECEIVE_SMS = 1;

    EditText day, dayWeight, goalWeight;
    Button insert, update, delete, view, enable;
    DBHelper2 DB;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        day = findViewById(R.id.day);
        dayWeight = findViewById(R.id.dayWeight);
        goalWeight = findViewById(R.id.goalWeight);

        insert = findViewById(R.id.buttonInsert);
        update = findViewById(R.id.buttonUpdate);
        delete = findViewById(R.id.buttonDelete);
        view = findViewById(R.id.buttonView);
        enable = findViewById(R.id.buttonEnable);
        DB = new DBHelper2(this);

        //CRUD implementation for data

        insert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String dayTXT = day.getText().toString();
                String dayWeightTXT = dayWeight.getText().toString();
                String goalWeightTXT = goalWeight.getText().toString();

                Boolean checkinsertdata = DB.insertuserdata(dayTXT, dayWeightTXT, goalWeightTXT);
                if (checkinsertdata == true)
                    Toast.makeText(MainActivity2.this, "New Entry Inserted", Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(MainActivity2.this, "New Entry Not Inserted", Toast.LENGTH_SHORT).show();
            }
        });

        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String dayTXT = day.getText().toString();
                String dayWeightTXT = dayWeight.getText().toString();
                String goalWeightTXT = goalWeight.getText().toString();

                Boolean checkupdatedata = DB.updateuserdata(dayTXT, dayWeightTXT, goalWeightTXT);
                if (checkupdatedata == true)
                    Toast.makeText(MainActivity2.this, "Entry Updated", Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(MainActivity2.this, "Entry Not Updated", Toast.LENGTH_SHORT).show();
            }
        });

        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String dayTXT = day.getText().toString();
                Boolean checkdeletedata = DB.deleteuserdata(dayTXT);
                if (checkdeletedata == true)
                    Toast.makeText(MainActivity2.this, "Entry Deleted", Toast.LENGTH_SHORT).show();
                else
                    Toast.makeText(MainActivity2.this, "Entry Not Updated", Toast.LENGTH_SHORT).show();
            }
        });

        view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Cursor res = DB.getData();
                if (res.getCount() == 0) {
                    Toast.makeText(MainActivity2.this, "No Entry Exists", Toast.LENGTH_SHORT).show();
                    return;
                }
                StringBuffer buffer = new StringBuffer();
                while (res.moveToNext()) {
                    buffer.append("Day :" + res.getString(0) + "\n");
                    buffer.append("Weight :" + res.getString(1) + "\n");
                    buffer.append("Goal Weight :" + res.getString(2) + "\n\n");
                }

                //Displays data properly after view is clicked

                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity2.this);
                builder.setCancelable(true);
                builder.setTitle("Daily Entries");
                builder.setMessage(buffer.toString());
                builder.show();

            }
        });
    }

    // ******code for SMS messaging below, I couldn't figure out the rest and had an issue with it*****

//        enable.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                if (ContextCompat.checkSelfPermission( MainActivity2.this, Manifest.permission.RECEIVE_SMS) == PackageManager.PERMISSION_GRANTED);
//                Toast.makeText(MainActivity2.this, "You have already granted this permission!", Toast.LENGTH_SHORT).show();
//            } else {
//                requestSMSPermission();
//            }
//
//
//
//        });
//
//    }
//
//    private void requestSMSPermission() {
//        if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.RECEIVE_SMS)) {
//            new AlertDialog.Builder(this)
//                    .setTitle("Permission needed")
//                    .setMessage("This permission is needed to send notification for reaching target weight goal")
//                    .setPositiveButton("ok", new DialogInterface.OnClickListener() {
//                        @Override
//                        public void onClick(DialogInterface dialogInterface, int i) {
//                            ActivityCompat.requestPermissions(MainActivity2.this, new String[] {Manifest.permission.RECEIVE_SMS}, MY_PERMISSIONS_REQUEST_RECEIVE_SMS);
//
//                        }
//                    })
//                    .setNegativeButton("cancel", new DialogInterface.OnClickListener() {
//                        @Override
//                        public void onClick(DialogInterface dialogInterface, int i) {
//                            dialogInterface.dismiss();
//
//                        }
//                    })
//                    .create().show();
//
//        } else {
//            ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.RECEIVE_SMS}, MY_PERMISSIONS_REQUEST_RECEIVE_SMS);
//        }
//    }
//
//    @Override
//    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
//        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
//        if (requestCode == MY_PERMISSIONS_REQUEST_RECEIVE_SMS) {
//            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
//                Toast.makeText(this, "Permission GRANTED", Toast.LENGTH_SHORT).show();
//            } else {
//                Toast.makeText(this, "Permission DENIED", Toast.LENGTH_SHORT).show();
//            }
//        }
//    }
}