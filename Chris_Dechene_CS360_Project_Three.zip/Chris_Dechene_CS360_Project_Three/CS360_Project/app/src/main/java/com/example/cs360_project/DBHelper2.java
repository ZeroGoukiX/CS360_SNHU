package com.example.cs360_project;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DBHelper2 extends SQLiteOpenHelper {

    public static final String DBNAME = "Userdata.db";

    public DBHelper2(@Nullable Context context) {
        super(context, "Userdata.db", null, 1);
    }

    //creates table for weight database
    @Override
    public void onCreate(SQLiteDatabase MyDB2) {
        MyDB2.execSQL("create Table userDetails(day TEXT primary key, dayWeight TEXT, goalWeight TEXT)");

    }

    @Override
    public void onUpgrade(SQLiteDatabase MyDB2, int i, int i1) {
        MyDB2.execSQL("drop Table if exists userDetails");

    }
    // boolean for create
    public Boolean insertuserdata(String day, String dayWeight, String goalWeight) {
        SQLiteDatabase MyDB2 = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("day", day);
        contentValues.put("dayweight", dayWeight);
        contentValues.put("goalweight", goalWeight);
        long result = MyDB2.insert("Userdetails", null, contentValues);
        if(result==-1){
            return false;
        }else{
            return true;
        }
    }

    //boolean for update data
    public Boolean updateuserdata(String day, String dayWeight, String goalWeight) {
        SQLiteDatabase MyDB2 = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("dayweight", dayWeight);
        contentValues.put("goalweight", goalWeight);
        Cursor cursor = MyDB2.rawQuery("Select * from Userdetails where day = ?", new String[]{day});
        if (cursor.getCount() > 0) {
            long result = MyDB2.update("Userdetails", contentValues, "day=?", new String[]{day});
            if (result == -1) {
                return false;
            } else {
                return true;
            }
        } else {
            return false;
        }
    }

    //boolean of delete data
    public Boolean deleteuserdata(String day) {
        SQLiteDatabase MyDB2 = this.getWritableDatabase();
        Cursor cursor = MyDB2.rawQuery("Select * from Userdetails where day = ?", new String[]{day});
        if (cursor.getCount() > 0) {
            long result = MyDB2.delete("Userdetails", "day=?", new String[]{day});
            if (result == -1) {
                return false;
            } else {
                return true;
            }
        } else {
            return false;
        }
    }

    //view data function
    public Cursor getData() {
        SQLiteDatabase MyDB2 = this.getWritableDatabase();
        Cursor cursor = MyDB2.rawQuery("Select * from Userdetails", null);
        return cursor;

}
}
